/*
 * approx.c - Si5351 parameter calibration for UperGrafx
 * Copyright (C) 2016 Naruko <unagi.kaihatu at gmail.com>
 * si5351.c からソースコードの整理をしました
 * 変数の精度をあげて算出の精度を上げました
 * PC 用に main 関数を付けました
 *
 * si5351.c - Si5351 library for avr-gcc
 *
 * Copyright (C) 2014 Jason Milldrum <milldrum@gmail.com>
 *
 * Some tuning algorithms derived from clk-si5351.c in the Linux kernel.
 * Sebastian Hesselbarth <sebastian.hesselbarth@gmail.com>
 * Rabeeh Khoury <rabeeh@solid-run.com>
 *
 * rational_best_approximation() derived from lib/rational.c in
 * the Linux kernel.
 * Copyright (C) 2009 emlix GmbH, Oskar Schirmer <oskar@scara.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include <math.h>
#include <stdint.h>

#define FREQ_BASE_INT (100000000ULL)
#define FREQ_BASE_DOUBLE pow(10, 8)
#define SI5351_XTAL_FREQ (27 * FREQ_BASE_INT)
#define SI5351_PLL_FIXED (900 * FREQ_BASE_INT)

#define SI5351_PLL_VCO_MIN (600 * FREQ_BASE_INT)
#define SI5351_PLL_VCO_MAX (900 * FREQ_BASE_INT)
#define SI5351_MULTISYNTH_MIN_FREQ (FREQ_BASE_INT)
#define SI5351_MULTISYNTH_DIVBY4_FREQ (150 * FREQ_BASE_INT)
#define SI5351_MULTISYNTH_MAX_FREQ (200 * FREQ_BASE_INT)
#define SI5351_MULTISYNTH67_MAX_FREQ SI5351_MULTISYNTH_DIVBY4_FREQ
#define SI5351_CLKOUT_MAX_FREQ SI5351_MULTISYNTH_MAX_FREQ
#define SI5351_CLKOUT67_MAX_FREQ SI5351_MULTISYNTH67_MAX_FREQ

#define SI5351_PLL_A_MIN (15)
#define SI5351_PLL_A_MAX (90)
#define SI5351_PLL_B_MAX (SI5351_PLL_C_MAX-1)
#define SI5351_PLL_C_MAX (1048575)
#define SI5351_MULTISYNTH_A_MIN (6)
#define SI5351_MULTISYNTH_A_MAX (1800)
#define SI5351_MULTISYNTH67_A_MAX (254)
#define SI5351_MULTISYNTH_B_MAX (SI5351_MULTISYNTH_C_MAX-1)
#define SI5351_MULTISYNTH_C_MAX (1048575)
#define SI5351_MULTISYNTH_P1_MAX ((1UL<<18)-1)
#define SI5351_MULTISYNTH_P2_MAX ((1UL<<20)-1)
#define SI5351_MULTISYNTH_P3_MAX ((1UL<<20)-1)

#define DETAIL
#ifdef DETAIL
#include <stdio.h>
#endif
struct si5351_register{
	int manual;
	uint32_t p1, p2, p3;
	uint64_t a,b,c;
#ifdef DETAIL
	double val; char str[0x40];
#endif
};
struct si5351_reg_pair{
	struct si5351_register pll, multisynth;
};
/*
 * Calculate best rational approximation for a given fraction
 * taking into account restricted register size, e.g. to find
 * appropriate values for a pll with 5 bit denominator and
 * 8 bit numerator register fields, trying to set up with a
 * frequency ratio of 3.1415, one would say:
 *
 * rational_best_approximation(31415, 10000,
 *              (1 << 8) - 1, (1 << 5) - 1, &n, &d);
 *
 * you may look at given_numerator as a fixed point number,
 * with the fractional part size described in given_denominator.
 *
 * for theoretical background, see:
 * http://en.wikipedia.org/wiki/Continued_fraction
 */

static void rational_best_approximation(
	uint64_t given_numerator, uint64_t given_denominator,
	uint64_t max_numerator, uint64_t max_denominator,
	uint64_t *best_numerator, uint64_t *best_denominator
)
{
	uint64_t n = given_numerator;
	uint64_t d = given_denominator;
	uint64_t n0 = 0, d0 = 1, n1 = 1, d1 = 0;
	while(1){
		uint64_t t, a;
		if((n1 > max_numerator) || (d1 > max_denominator)){
			n1 = n0;
			d1 = d0;
			break;
		}
		if(d == 0){
			break;
		}
		t = d;
		a = n / d;
		d = n % d;
		n = t;
		t = n0 + a * n1;
		n0 = n1;
		n1 = t;
		t = d0 + a * d1;
		d0 = d1;
		d1 = t;
	}
	*best_numerator = n1;
	*best_denominator = d1;
}

static void equation(struct si5351_register *reg)
{
	reg->p3  = reg->c;
	reg->p2  = (128 * reg->b) % reg->c;
	reg->p1  = 128 * reg->a;
	reg->p1 += (128 * reg->b / reg->c);
	reg->p1 -= 512;
}

static void pll_calc(uint64_t target_freq, struct si5351_register *reg)
{
	uint64_t ref_freq = (uint64_t) SI5351_XTAL_FREQ;

	/* PLL bounds checking */
	if(target_freq < SI5351_PLL_VCO_MIN){
		target_freq = SI5351_PLL_VCO_MIN;
	}
	if(target_freq > SI5351_PLL_VCO_MAX){
		target_freq = SI5351_PLL_VCO_MAX;
	}

	/* Determine integer part of feedback equation */
	reg->a = target_freq / ref_freq;
	reg->b = 0;
	reg->c = 1;

	if(reg->a < SI5351_PLL_A_MIN){
		target_freq = ref_freq * SI5351_PLL_A_MIN;
	}
	if(reg->a > SI5351_PLL_A_MAX){
		target_freq = ref_freq * SI5351_PLL_A_MAX;
	}

	/* find best approximation for b/c = fVCO mod fIN */
	{
		uint64_t denom = FREQ_BASE_INT;
		uint64_t lltmp;
		lltmp = target_freq % ref_freq;
		lltmp *= denom;
		uint64_t rfrac = lltmp / ref_freq;

		if(rfrac != 0){
			rational_best_approximation(
				rfrac, denom,
				SI5351_PLL_B_MAX, SI5351_PLL_C_MAX, 
				&reg->b, &reg->c
			);
		}
	}

	/* calculate parameters */
	equation(reg);
}
/*
4.1.2.1.  Integer Divide Values(MSx_INT)
If any of the MS0-MS5 is an even integer, Multisynth integer mode may be enabled by setting MSx_INT=1 (see
registers  16-21,  bit  6).  In  most  cases  setting  this  bit  will  improve  jitter  when  using  even  integer  divide  values.
Multisynths 6 and 7 inherently operate in integer mode, and so there is no register to turn integer mode on or off.
4.1.3. Output Multisynth Divider Equations (150 MHz <Fout<=200 MHz)
Output frequencies greater than 150 MHz are available on Multisynths 0-5. For this frequency range a divide value
of 4 must be used by setting
MSx_P1=0,
MSx_P2=0,
MSx_P3=1,
MSx_INT=1, and
MSx_DIVBY4[1:0]=11b.
Set the appropriate feedback Multisynth to generate fVCO = Fout*4.
*/
static uint64_t multisynth_calc(double freq_in, struct si5351_register *reg)
{
	uint8_t divby4;
	uint64_t freq = (uint64_t) (freq_in * FREQ_BASE_DOUBLE);
	/* Multisynth bounds checking */
	if(freq > SI5351_MULTISYNTH_MAX_FREQ){
		freq = SI5351_MULTISYNTH_MAX_FREQ;
	}
	if(freq < SI5351_MULTISYNTH_MIN_FREQ){
		freq = SI5351_MULTISYNTH_MIN_FREQ;
	}

	divby4 = 0;
	if(freq > SI5351_MULTISYNTH_DIVBY4_FREQ){
		divby4 = 1;
	}

	/* Find largest integer divider for max */
	/* VCO frequency and given target frequency */
	reg->b = 0;
	reg->c = 1;
	if(divby4 == 0){
		reg->a = SI5351_PLL_VCO_MAX / freq;
	}else{
		reg->a = 4;
	}
	const uint64_t pll_freq = reg->a * freq;

	/* Calculate parameters */
	if(divby4){
		reg->p3 = 1;
		reg->p2 = 0;
		reg->p1 = 0;
	}else{
		equation(reg);
	}

	return pll_freq;
}

static double multi_get(struct si5351_register *t)
{
	return (double) t->a + (double) t->b / (double) t->c;
}
static int pn_bound_check(struct si5351_register *t)
{
	if(t->p1 >= SI5351_MULTISYNTH_P1_MAX){
		return 1;
	}
	if(t->p2 >= SI5351_MULTISYNTH_P2_MAX){
		return 1;
	}
	if(t->p3 >= SI5351_MULTISYNTH_P3_MAX){
		return 1;
	}
#ifdef DETAIL
	t->val = multi_get(t);
	if(t->b == 0){
		snprintf(t->str, sizeof(t->str) - 1, "%I64u", t->a);
	}else{
		snprintf(t->str, sizeof(t->str) - 1, "(%I64u + %I64u/%I64u)", t->a, t->b, t->c);
	}
#endif
	return 0;
}

static int approx_main(double target, const double adjust, struct si5351_reg_pair *r)
{
	uint64_t pll_freq;
	if(r->multisynth.manual == 0){
		target *= adjust;
		pll_freq = multisynth_calc(target, &r->multisynth);
	}else{
		equation(&r->multisynth);
		const double pll_d = 27.0 * adjust * multi_get(&r->pll);
		target = pll_d / multi_get(&r->multisynth);
		pll_freq = (uint64_t) (pll_d * FREQ_BASE_DOUBLE);
	}
	if(r->pll.manual == 0){
		pll_calc(pll_freq, &r->pll);
	}else{
		equation(&r->pll);
	}
	//printf("%I64u\n", pll_freq);
	if(pn_bound_check(&r->multisynth)){
		return 0;
	}
	if(pn_bound_check(&r->pll)){
		return 0;
	}

#ifdef DETAIL
	const double outfreq = 27.0 * r->pll.val / r->multisynth.val;
	printf("//%13.9f: %13.9f <- ", target, outfreq);
	printf("%d * %s / %s\n", 27, r->pll.str, r->multisynth.str);
#endif
	return 1;
}
static void multisynth_set(const struct si5351_register *r, uint8_t *d, uint8_t div)
{
	uint8_t temp;
	*d++ =  (r->p3 >> 8) & 0xff;
	*d++ = r->p3 & 0xff;
	temp = (r->p1 >> 16) & 0x03;
	if(div != 0){
		div -= 1;
		temp |= div << 4;
	}
	*d++ = temp; //ms0_divby4
	*d++ = (r->p1 >> 8) & 0xff;
	*d++ = r->p1 & 0xff;
	temp = (r->p3 >> 12) & 0xf0;
	temp |= (r->p2 >> 16) & 0x0f;
	*d++ = temp;
	*d++ = (r->p2 >> 8) & 0xff;
	*d++ = r->p2 & 0xff;
}

#include "approx.h"
#define FREQLIST_SIZE (4)
static int si5351_calibration_main(uint8_t *const d, const double *freqlist, const double adjust)
{
	uint8_t *dd = d;
	{
/*
#PLL A
# Input Frequency (MHz) = 27.000000000
# F divider = 1
# PFD (MHz) = 27.000000000
# VCO Frequency (MHz) =  677.376000000
# Feedback Divider = 25  11/125
#Output Clocks
#Channel 0
# Output Frequency (MHz) = 11.289600000
# Multisynth Output Frequency (MHz) = 11.289600000
# Multisynth Divider = 60
# R Divider = 1
*/
#if 1
		struct si5351_reg_pair r = {
			.pll = {.manual = adjust == 1.0 ? 1 : 0, .a = 25, .b = 11, .c = 125},
			.multisynth = {.manual = adjust == 1.0 ? 1 : 0, .a = 60, .b = 0, .c = 1}
		};
#else
		struct si5351_reg_pair r;
		r.pll.manual = 0;
		r.multisynth.manual = 0;
#endif
		if(approx_main(freqlist[0], adjust, &r) == 0){
			return 0;
		}
		multisynth_set(&r.pll, dd, 0);
		dd += 8;
		multisynth_set(&r.multisynth, dd, 1);
		dd += 8;
	}
	for(size_t i = 1; i < FREQLIST_SIZE; i += 1){
		struct si5351_reg_pair r;
		r.pll.manual = 0;
		r.multisynth.manual = 0;
		if(approx_main(freqlist[i], adjust, &r) == 0){
			return 0;
		}
		multisynth_set(&r.pll, dd, 0);
		dd += 8;
		multisynth_set(&r.multisynth, dd, 1);
		dd += 8;
	}
	uint32_t sum = 0;
	int i;
	for(i = 0; i < APPROX_DATA_SIZE - 2; i++){
		sum += d[i] ^ 0x88;
	}
	sum ^= 0x721a;
	d[i] = sum & 0xff;
	d[i+1] = (sum >> 8) & 0xff;
	return 1;
}
/*
1080p pixel clock -> ps
PC Engine Master clock -> pm
lines -> 263 or 262 (register configuration)

ps / (1650 * 750) = pm / (1365 * lines)
ps = pm * 1650 * 750 / (1365 * lines)

pin#/CLK#/PLL/assignments
10 0 A Audio I2S bit clock (sample freq * 64)
 9 1 A Audio master clock (sample freq * 256)
 6 2 B 1080p pixel clock
*/
static double vasync(double hd_hcount, double hd_vcount, double pce_vcount)
{
	return 21.477270 * hd_hcount * hd_vcount / 1365 / pce_vcount;
}
#define HD_HCOUNT (2200.0)
#define HD_VCOUNT (1125.0)
#define HDCOUNTER_DEFAULTVAL (HD_HCOUNT * HD_VCOUNT * 801.0)
static int si5351_upergrafx_calibration(double val, uint8_t *const d, uint8_t *r15)
{
/*
1080p の対応
- checksum の算出変更
- hdcounter は 720p では従来の2倍の値を firmware が送信する
- clibration の設定値は 1080p の pixel clock を使う. 720p はその1/2なので pll レジスタで 1/2 を設定する.
720p の 1 frame pixel count * 2 は 1080 の 1 frame pixel count と同じ.
1650*750*2 -> 2,475,000; 2200*1125 0 -> 2,475,000
*/
	double freqlist[FREQLIST_SIZE] = { //UNIT:MHz
		0.0441 * 256, //audio CDDA 44.1k * 256
		74.250000 * 2, //video async 60.00Hz
#define VASYNC(LINE) vasync(HD_HCOUNT, HD_VCOUNT, LINE)
		VASYNC(263.0), //video vsync 59.83Hz
		VASYNC(262.0) //video vsync 60.02Hz
#undef VASYNC
	};
	r15[1] = 0x4f; //CLK0 uses PLLA, MS0 integer mode
	r15[2] = 0x4f; //CLK1 uses PLLA, MS1 integer mode
	r15[3] = 0x6f; //CLK2 uses PLLB, MS2 integer mode
	return si5351_calibration_main(d, freqlist, HDCOUNTER_DEFAULTVAL / val);
}
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#if defined(_WIN32) || defined(_WIN64)
#include <windows.h>
#define MODE WCHAR
#define ML(x) L##x
#else
#define MODE char
#define ML(x) ##x
#endif

static void dump_u8_array(const char *macro, const char *array_name, int array_size, const uint8_t *d)
{
	printf("#define %s (%d)\n", macro, array_size);
	printf("static const uint8_t %s[%s] = {\n", array_name, macro);
	for(int i = 0; i < array_size; i++){
		printf("0x%02x,", d[i]);
		if((i & 7) == 7){
			puts("");
		}else{
			printf(" ");
		}
	}
	puts("};");
}
static FILE *utf8fopen(const char *filename, const MODE *mode)
{
#if defined(_WIN32) || defined(_WIN64)
	WCHAR wname[0x200];
	int r;
	r = MultiByteToWideChar(CP_UTF8, 0, filename, -1, wname, sizeof(wname));
	assert(r!= 0);
	return _wfopen(wname, mode);
#else
	return fopen(filename, mode);
#endif
}
int main(int c, char **v)
{
	uint8_t ms[APPROX_DATA_SIZE];
	uint8_t r15[] = {
		0x00, 0x0f, 0x0f, 0x0f, 0x80, 0x80, 0x80, 0x80,
		0x80, 0xaa, 0xaa
	};
	memset(ms, 0, sizeof(ms));
	assert(c);
	switch(c){
	case 1:{
		si5351_upergrafx_calibration(HDCOUNTER_DEFAULTVAL, ms, r15);
		dump_u8_array("SI5351_R15_SIZE", "si5351_r15_r25", sizeof(r15), r15);
		static const struct param{
			const char *name;
			double px, w, h;
		}tt[] = {
			{"H3",  74.25, 1650,  750},
			{"V4", 102.10, 1712,  994},
			{"HD", 148.50, 2200, 1125},
			{NULL, 0, 0, 0}
		};
		const struct param *t = tt;
		while(t->name != NULL){
			double freqlist[FREQLIST_SIZE] = {
				0.0441 * 256, t->px,
				vasync(t->w, t->h, 263.0),
				vasync(t->w, t->h, 262.0)
			};
			si5351_calibration_main(ms, freqlist, 1.0);
			printf("#ifdef VIDEO_RESOLUTION_%s\n", t->name);
			dump_u8_array("SI5351_MS_SIZE", "si5351_ms_base", APPROX_DATA_SIZE - 2, ms);
			puts("#endif");
			t++;
		}
		}break;
	case 3:
		si5351_upergrafx_calibration(strtod(v[1], NULL), ms, r15);
		FILE *f = utf8fopen(v[2], ML("wb"));
		if(f == NULL){
			return 1;
		}
		fwrite(ms, 1, sizeof(ms), f);
		fclose(f);
		break;
	case 4: case 5:{
		int i = 1;
		double standrd_pixel_clock = strtod(v[i++], NULL);
		double hd_hcount = strtod(v[i++], NULL);
		double hd_vcount = strtod(v[i++], NULL);
		double freqlist[FREQLIST_SIZE] = {
			0.0441 * 256, standrd_pixel_clock,
			vasync(hd_hcount, hd_vcount, 263.0),
			vasync(hd_hcount, hd_vcount, 262.0)
		};
		double adjust = 1.0;
		if(c == 5){
			adjust = strtod(v[i++], NULL);
		}
		si5351_calibration_main(ms, freqlist, adjust);
		dump_u8_array("SI5351_MS_SIZE", "si5351_ms_base", APPROX_DATA_SIZE - 2, ms);
		}break;
	default:
		puts("unknown arguments");
		return -1;
	}
	return 0;
}
